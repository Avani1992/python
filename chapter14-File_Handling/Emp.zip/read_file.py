f=open("abc.txt","r")
print(f.read(4)) # Pyth
print(f.readline()) # on
print(f.read(3)) # Jav
# print(f.read()) # a,Pearl,Ruby,C++,C
print(f.readlines()) # ['a\n', 'Pearl\n', 'Ruby\n', 'C++\n', 'C']